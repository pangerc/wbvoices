export const runtime = "edge";

import { NextRequest, NextResponse } from "next/server";

// Slovenian voice ID from the API response
const SLOVENIAN_VOICE_ID = "63b409fc241a82001d51c7ac";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * POST /api/streamAudio
 * Body: { text: string }
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const text = body?.text ?? "Zdravo, kako si?"; // Default Slovenian greeting

    console.log("Converting text to speech:", text);
    const apiKey = process.env.LOVO_API_KEY;
    console.log("Using API key:", apiKey);

    // Create TTS job
    const createResponse = await fetch("https://api.genny.lovo.ai/api/v1/tts", {
      method: "POST",
      headers: {
        Authorization: `x-api-key: ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text,
        speaker_id: SLOVENIAN_VOICE_ID,
        speed: 1.0,
        pitch: 1.0,
        format: "mp3",
      }),
    });

    if (!createResponse.ok) {
      const errorText = await createResponse.text();
      console.error("Lovo API error response:", errorText);
      throw new Error(
        `Failed to create TTS job. API Key: ${apiKey}. Error: ${errorText}`
      );
    }

    const { id: jobId } = await createResponse.json();
    console.log("TTS job created:", jobId);

    // Poll for job completion
    let audioUrl: string | null = null;
    for (let i = 0; i < 10; i++) {
      const statusResponse = await fetch(
        `https://api.genny.lovo.ai/api/v1/tts/${jobId}`,
        {
          headers: {
            Authorization: `x-api-key: ${apiKey}`,
          },
        }
      );

      if (!statusResponse.ok) {
        const errorText = await statusResponse.text();
        throw new Error(
          `Failed to check job status. API Key: ${apiKey}. Error: ${errorText}`
        );
      }

      const status = await statusResponse.json();
      console.log("Job status:", status);

      if (status.status === "completed") {
        audioUrl = status.audio_url;
        break;
      }

      if (status.status === "failed") {
        throw new Error(`TTS job failed. API Key: ${apiKey}`);
      }

      // Wait before checking again
      await sleep(1000);
    }

    if (!audioUrl) {
      throw new Error(
        `Timeout waiting for TTS job completion. API Key: ${apiKey}`
      );
    }

    // Fetch the audio file
    const audioResponse = await fetch(audioUrl);
    if (!audioResponse.ok) {
      throw new Error(`Failed to fetch audio file. API Key: ${apiKey}`);
    }

    const audioArrayBuffer = await audioResponse.arrayBuffer();

    // Return the audio file
    return new NextResponse(audioArrayBuffer, {
      headers: {
        "Content-Type": "audio/mpeg",
      },
    });
  } catch (err) {
    if (err instanceof Error) {
      console.error("Lovo API error:", err.message);
      return NextResponse.json({ error: err.message }, { status: 500 });
    }
    return NextResponse.json(
      { error: "Unknown error occurred" },
      { status: 500 }
    );
  }
}
